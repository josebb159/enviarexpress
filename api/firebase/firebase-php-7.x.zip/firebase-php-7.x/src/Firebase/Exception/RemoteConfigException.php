<?php

declare(strict_types=1);

namespace Kreait\Firebase\Exception;

interface RemoteConfigException extends FirebaseException
{
}
